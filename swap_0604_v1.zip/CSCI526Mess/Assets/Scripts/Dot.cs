﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dot : MonoBehaviour
{
    public int row;
    public int col;
    public int targetX;
    public int targetY;
    //private GameObject otherDot;
    private Board board;
    private Vector2 firstTouchPosition;
    private Vector2 finalTouchPosition;
    public Vector2 tempPosition;
    public float swipeAngle = 0;
    // Start is called before the first frame update
    void Start()
    {
        board = FindObjectOfType<Board>();
        targetX = Mathf.RoundToInt(transform.position.x);
        targetY = Mathf.RoundToInt(transform.position.y);
        col = targetX;
        row = targetY;
    }
    
    // Update is called once per frame
    /*
    void Update()
    {   
        targetX = col;
        targetY = row;
        if (Mathf.Abs(targetX - transform.position.x) > .1)
        {
            //move towards the target
            tempPosition = new Vector2(targetX, transform.position.y);
            transform.position = Vector2.Lerp(transform.position, tempPosition, .4f);
        }
        else
        {
            //set the position directly
            tempPosition = new Vector2(targetX, transform.position.y);
            transform.position = tempPosition;
            board.allDots[col, row] = this.gameObject;
        }

        if (Mathf.Abs(targetY - transform.position.y) > .1)
        {
            //move towards the target
            tempPosition = new Vector2(transform.position.x, targetY);
            transform.position = Vector2.Lerp(transform.position, tempPosition, .4f);
        }
        else
        {
            //set the position directly
            tempPosition = new Vector2(transform.position.x, targetY);
            transform.position = tempPosition;
            board.allDots[col, row] = this.gameObject;
        }

    
    }
    
    void OnMouseDown()
    {
        firstTouchPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
    }
    */ 
    void OnMouseUp()
    {
        //finalTouchPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        //CalculateAngle();
        //Debug.Log("MouseUP");
        transform.position = board.tilesPos[col,row];
    }
  
    
    private void OnMouseDrag()
    {
        Vector2 dragPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        //tempPosition = dragPosition;
        transform.position = new Vector2(dragPosition.x, dragPosition.y);

    }
    
    void OnTriggerEnter2D(Collider2D oDot)
    {
        Debug.Log("Tile Collision: "+ oDot.GetComponent<BackgroundTile>().col + ", "+ oDot.GetComponent<BackgroundTile>().row);
        //Debug.Log("Drag dot: " +col + ", " +row);
        GameObject otherDot = board.allDots[oDot.GetComponent<BackgroundTile>().col, oDot.GetComponent<BackgroundTile>().row];
        board.allDots[oDot.GetComponent<BackgroundTile>().col, oDot.GetComponent<BackgroundTile>().row] = this.gameObject;
        board.allDots[col, row] = otherDot;
        otherDot.GetComponent<Dot>().row = row;
        otherDot.GetComponent<Dot>().col = col;
        otherDot.GetComponent<Dot>().OnMouseUp();
        row = oDot.GetComponent<BackgroundTile>().row;
        col = oDot.GetComponent<BackgroundTile>().col;
        Debug.Log("Drag position: " + row + ", " + col);
       
    }
 
    /*
    void CalculateAngle()
    {
        swipeAngle = Mathf.Atan2(finalTouchPosition.y - firstTouchPosition.y, finalTouchPosition.x - firstTouchPosition.x)*180/Mathf.PI;
        //Debug.Log(swipeAngle);
        MovePieces();
    }
    void MovePieces()
    {
        if(swipeAngle <=45 && swipeAngle > -45 && col < board.width)
        {//right 
            otherDot = board.allDots[col + 1, row];
            otherDot.GetComponent<Dot>().col -= 1;
            col += 1; 
        }
        else if (swipeAngle <= 135 && swipeAngle > 45 && row < board.height)
        {//up
            otherDot = board.allDots[col, row+1];
            otherDot.GetComponent<Dot>().row -= 1;
            row += 1;
        }
        else if ((swipeAngle > 135 || swipeAngle <= -135)&& col > 0)
        {//left
            otherDot = board.allDots[col - 1, row];
            otherDot.GetComponent<Dot>().col += 1;
            col -= 1;
        }
        else if (swipeAngle < -45 && swipeAngle >= -135  && row > 0)
        {//down
            otherDot = board.allDots[col, row-1];
            otherDot.GetComponent<Dot>().row += 1;
            row -= 1;
        }
    }
    */
}
