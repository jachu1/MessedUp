﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RainBowDotHandler : CircleHandler
{
    
    public override void Start()
    {
        board = FindObjectOfType<BoardManager>();
        targetX = Mathf.RoundToInt(transform.position.x);
        targetY = Mathf.RoundToInt(transform.position.y)+8;
        col = targetX;
        row = targetY - 5;
    }
    // Start is called before the first frame update
    public override void OnMouseDown()
    {
        Vector2 temp = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Debug.Log(temp.x + ", " + temp.y);
    }
    public override void OnMouseDrag()
    {
        Vector2 dragPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        //tempPosition = dragPosition;
        transform.position = new Vector2(dragPosition.x, dragPosition.y);

    }
    public override void OnMouseUp()
    {
        //finalTouchPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        //CalculateAngle();
        Debug.Log("MouseUP");
        //Debug.Log(this.board);
        Debug.Log(col + ", " + row);
        Debug.Log("Next Pos: "+this.board.tilesPos[col, row].x + ", " + this.board.tilesPos[col, row].y);
        transform.position = this.board.tilesPos[col, row];
    }
    private void OnTriggerEnter2D(Collider2D oDot)
    {
        Debug.Log("Tile Collision: " + oDot.GetComponent<BackgroundTile>().col + ", " + oDot.GetComponent<BackgroundTile>().row);
        //Debug.Log("Drag dot: " +col + ", " +row);
        int colorTemp = board.board[oDot.GetComponent<BackgroundTile>().col, oDot.GetComponent<BackgroundTile>().row].color;
        GameObject otherDot = board.board[oDot.GetComponent<BackgroundTile>().col, oDot.GetComponent<BackgroundTile>().row].circleObject;
        board.board[oDot.GetComponent<BackgroundTile>().col, oDot.GetComponent<BackgroundTile>().row].circleObject = this.gameObject;
        board.board[oDot.GetComponent<BackgroundTile>().col, oDot.GetComponent<BackgroundTile>().row].color = board.board[col, row].color;
        board.board[col, row].circleObject = otherDot;
        board.board[col, row].color = colorTemp;
        otherDot.GetComponent<CircleHandler>().row = row;
        otherDot.GetComponent<CircleHandler>().col = col;
        otherDot.GetComponent<CircleHandler>().SwapCircle();
        row = oDot.GetComponent<BackgroundTile>().row;
        col = oDot.GetComponent<BackgroundTile>().col;
        //Debug.Log("Drag position: " + col + ", " + row);

    }
    public override void SwapCircle()
    {
        board = FindObjectOfType<BoardManager>();
        OnMouseUp();
        //Debug.Log(board.tilesPos[col, row].x + ", " + board.tilesPos[col, row].y);
        //this.transform.position = board.tilesPos[col, row];
    }
}
