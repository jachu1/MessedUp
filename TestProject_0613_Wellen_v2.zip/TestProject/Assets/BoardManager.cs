﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BoardManager : MonoBehaviour
{
    //TODO
    //Programatically center camera

    public int binA;
    public int binB;
    public int binC;
    public int binD;
    public int binE;

    public Text binAText;
    public Text binBText;
    public Text binCText;
    public Text binDText;
    public Text binEText;


    public struct Circle
    {
        public int color;
        public GameObject circleObject;
        //public CircleHandler CH;
        public int dropDistance;
        public int matchNumber;
    }
    public GameObject rainBowDot;
    public GameObject tilePreFab;
    public int width;
    public int height;
    public int offset = 5;
    public Circle[,] board;
    public Vector2[,] tilesPos;
    public GameObject[,] backgroundTiles;
    private Circle circleClone = new Circle();
    private int randomX;
    private int randomY;

    [SerializeField] private Material cRed;
    [SerializeField] private Material cYellow;
    [SerializeField] private Material cGreen;
    [SerializeField] private Material cBlue;
    [SerializeField] private Material cPurple;

    // Start is called before the first frame update
    void Start()
    {
        board = new Circle[height, width];
        tilesPos = new Vector2[height, width];
        backgroundTiles = new GameObject[height, width];
        randomX = Random.Range(0, width);
        randomY = Random.Range(0, height);
        InitBoard();
        binA = 0;
        binB = 0;
        binC = 0;
        binD = 0;
        binE = 0;
    }

    // Update is called once per frame
    void Update()
    {
        /*if (Input.GetMouseButtonDown(0))
        {
            Debug.Log(Camera.main.ScreenToWorldPoint(Input.mousePosition));
            Debug.Log("HELLO");
        }*/
    }

    private void InitBoard()
    {
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {   
                
                SpawnCircle(x, y, height);
            }
        }
         SkyfallGems();
    }

    public void SpawnCircle(int x, int y, int drop)
    {
        GameObject circle;
        /*
        if (x == randomX && y == randomY)
        {
            circle = Instantiate(rainBowDot, new Vector2(x, y + offset), Quaternion.identity) as GameObject;
        }
        else
        {
            circle = (GameObject)Instantiate(Resources.Load("Circle"), new Vector2(x, y + offset), Quaternion.identity);
        }
        */
        circle = (GameObject)Instantiate(Resources.Load("Circle"), new Vector2(x, y + offset), Quaternion.identity);
        GameObject backgroundTile = Instantiate(tilePreFab, new Vector2(x, y+offset-drop), Quaternion.identity) as GameObject;
        circle.transform.parent = this.transform;
        circle.name = "C( " + x + ", " + y + " )";
        backgroundTile.transform.parent = this.transform;
        backgroundTile.name = "( " + x + ", " + y + " )";
        
        if (board[x, y].circleObject != null)
        {
            DestroyObject(board[x, y].circleObject);
        }
        backgroundTiles[x, y] = backgroundTile;
        tilesPos[x, y] = new Vector2(x, y + offset - drop);

        Debug.Log(tilesPos[x, y].x + ", " + tilesPos[x, y].y);
        board[x, y] = new Circle
        {
            circleObject = circle,
            dropDistance = drop,
            //(x==0&&y==0)? circle.GetComponent<RainBowDotHandler>() : 
            //CH = circle.GetComponent<CircleHandler>(),
            matchNumber = 0
        };

        SetColor(x, y);
    }

    public void SpawnCircle2(int x, int y, int drop)
    {
        GameObject circle;
        /*
        if (x == randomX && y == randomY)
        {
            circle = Instantiate(rainBowDot, new Vector2(x, y + offset), Quaternion.identity) as GameObject;
        }
        else
        {
            circle = (GameObject)Instantiate(Resources.Load("Circle"), new Vector2(x, y + offset), Quaternion.identity);
        }
        */
        circle = (GameObject)Instantiate(Resources.Load("Circle"), new Vector2(x, y + offset), Quaternion.identity);      
        circle.transform.parent = this.transform.parent;
        circle.name = "C( " + x + ", " + y + " )";
       
        if (board[x, y].circleObject != null)
        {
            DestroyObject(board[x, y].circleObject);
        }              
        //Debug.Log(tilePos[x, y].x + ", " + tilePos[x, y].y);
        board[x, y] = new Circle
        {
            circleObject = circle,
            dropDistance = drop,
            //(x==0&&y==0)? circle.GetComponent<RainBowDotHandler>() : 
            //CH = circle.GetComponent<CircleHandler>(),
            matchNumber = 0
        };

        SetColor(x, y);
    }
    public void CreateRainbowDot(int x, int y)
    {
        GameObject rainbowDot = Instantiate(rainBowDot, new Vector2(x, y-3), Quaternion.identity) as GameObject;
        rainbowDot.transform.parent = this.transform.parent;
        rainbowDot.name = "RC( " + x + ", " + y + " )";
        board[x, y].circleObject = rainbowDot;
        SetColor(x, y);
    }

    private void SetColor(int x, int y)
    {
        int randomColor = Random.Range(0, 5);

        switch (randomColor)
        {
            case 0: // fire
                board[x, y].circleObject.transform.GetComponent<Renderer>().material = cRed;
                break;
            case 1: // water
                board[x, y].circleObject.transform.GetComponent<Renderer>().material = cBlue;
                break;
            case 2: // wood
                board[x, y].circleObject.transform.GetComponent<Renderer>().material = cGreen;
                break;
            case 3: // light
                board[x, y].circleObject.transform.GetComponent<Renderer>().material = cYellow;
                break;
            case 4: // dark
                board[x, y].circleObject.transform.GetComponent<Renderer>().material = cPurple;
                break;
        }
        board[x, y].color = randomColor;
    }

    public void SkyfallGems()
    {
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                if (board[x, y].dropDistance > 0)
                {            
                        board[x, y].circleObject.GetComponent<CircleHandler>().InitDrop(board[x, y].dropDistance);                 
                        board[x, y].dropDistance = 0;
                }
            }
        }
    }

    /*public void SetBinCountText()
    {
        binAText.text = "Count: " + binA.ToString();
        binBText.text = "Count: " + binB.ToString();
        binCText.text = "Count: " + binC.ToString();
        binDText.text = "Count: " + binD.ToString();
        binEText.text = "Count: " + binE.ToString();
    }*/
}
