﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CircleHandler : MonoBehaviour
{
    private Vector2 dropTarget = Vector2.zero;
    private Vector2 touchPos;

    public int targetX;
    public int targetY;
    public int row;
    public int col;
    private BoardManager board;

    // Start is called before the first frame update
    void Start()
    {
        board = FindObjectOfType<BoardManager>();
        targetX = (int)transform.position.x;
        targetY = (int)transform.position.y;
        col = targetX;
        row = targetY - 5;
    }

    // Update is called once per frame
    void Update()
    {

    }

    private void OnMouseDown()
    {
        Debug.Log(col);
        Debug.Log(row);
    }


    public void InitDrop(int dropDistance)
    {
        dropTarget = new Vector2(transform.position.x, transform.position.y - dropDistance);
        StartCoroutine(DropCircle());
    }

    private IEnumerator DropCircle()
    {
        WaitForSeconds frameTime = new WaitForSeconds(0.01f);
        Vector2 startPos = transform.position;
        float lerpPercent = 0;

        while (lerpPercent <= 1)
        {
            transform.position = Vector2.Lerp(startPos, dropTarget, lerpPercent);
            lerpPercent += 0.05f;
            yield return frameTime;
        }

        transform.position = dropTarget;
    }

    /*void OnMouseOver()
    {
        touchPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Debug.Log(touchPos);
        if (Input.GetMouseButtonDown(0))
        {
            Debug.Log("HIA THERE");
        }
        Debug.Log("HELLO");
    }*/
}
